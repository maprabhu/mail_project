<div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
        	
				<img src="<?php echo base_url('assets/uploads/attach_file'.'/'.$image);?>">

        </section>
        </div>