<div class="content-wrapper">
    <input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>" />
        <!-- Content Header (Page header) -->
        <section class="content-header">

            <h1>
            Payment Confirmation Page
            <small></small>
          </h1>
          <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
            <li class="active"><a href="#">Payment Success</a></li>
          </ol>
        </section> 
        <section class="content">
          <!-- Small boxes (Stat box) -->
          <div class="row">
              <div class="col-lg-3 col-xs-6">
              <h2>Payment Success</h2>
              </div>
          </div>
        </section>
        
        

</div>       

    
<!-- DATA TABES SCRIPT -->
